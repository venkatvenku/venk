package com.read.data;

import java.net.SocketTimeoutException;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.dao.DbConnection;
import com.data.format.SplitData;

public class RunApiServices {
	final static Logger logger = Logger.getLogger(RunApiServices.class);		
	public Map getData(String sql) {
		 Map<Integer,HashMap<String, String>> return_map = null;
		 DbConnection dbc = new DbConnection();
		 Connection con = null;
		 PreparedStatement pstmt = null;
		 ResultSet rst = null;

		 String apiName = "", 
				service = "", 
				apiURL = "", 
				request = "", 
				status = "";
		 int id = 0;		
		try
       {
			Map<Integer,String> map = new HashMap<Integer, String>();
//			String sql = "select * from APIC_HEARTBEAT_SERVICES where status='Y'";
			System.out.println("Sql: "+sql);
			con = dbc.getConnection();
			pstmt = con.prepareStatement(sql);
			rst = pstmt.executeQuery();
			int i=0;
			while(rst.next()) {
				i++;
				String temp = "";
				id = rst.getInt(1);
				apiName = rst.getString(2);
				System.out.println("api name   "+apiName);
				apiURL = rst.getString(3);
				service = rst.getString(4);

				request = rst.getString(5);
				status = rst.getString(6);
				temp = id+"!@#"+apiName+"!@#"+service+"!@#"+apiURL+"!@#"+request+"!@#"+status;
				System.out.println("temp   "+temp);
				map.put(i,temp);
			}					
			rst.close();
			con.close();
			System.out.println("i value is   "+i);
			  SplitData spd = new SplitData();
//			  System.out.println("map is  "+map);
	            try {
					return_map=  spd.splitData(map);
				} catch (SocketTimeoutException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}		
       } catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		logger.error(e);
	}
		
		return return_map;
	}
public static void main(String[] args) {	
}
}