package com.read.data;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;

import com.api.ApiCalls;
import com.dao.DbConnection;
import com.data.format.SplitData;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class GetStatus {
	String filepath = "resources/statuscode.properties";
//	static String statusCodes = "/statuscode.properties";//statuscodes Data
	final static Logger logger = Logger.getLogger(SplitData.class);
	
	public Map getStatu(String api_name,String service,String path) {
		Client client = Client.create();
		Map<String,String> map = new HashMap<String, String>();
		
		ApiCalls apc = new ApiCalls();
		apc.setupHandler();
			Properties prop = new Properties();
			try {
				prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(filepath));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		 DbConnection dbc = new DbConnection();
		 Connection con = null;
		 PreparedStatement pstmt = null;
		 ResultSet rst = null;

		 String apiName = "", 
				apiURL = "", 
				request = "", 
				status = "";
		 int id = 0;		
		try
       {
//			Map<Integer,String> map = new HashMap<Integer, String>();
			String sql = "select * from MISAPP.APIC_HEARTBEAT_SERVICES where API_NAME='"+api_name+"' and service='"+service+"'";
			System.out.println("Sql: "+sql);
			con = dbc.getConnection();
			pstmt = con.prepareStatement(sql);
			rst = pstmt.executeQuery();
			int i=0;
			while(rst.next()) {
				i++;
				String temp = "";
				id = rst.getInt(1);
				apiURL = rst.getString(3);
				request = rst.getString(5);
			}					
			rst.close();
			con.close();
			
			String connect_statuscode = apc.connectToURL(apiURL);
			String Connect_Time_out = "";
			String Read_Time_Out = "";
			ClientResponse response = null;
		    	try {   	
		    		
		     		WebResource webResource = client.resource(apiURL);
		     		client.setConnectTimeout(10*1000);//IN seconds i:e; 10 seconds
		     		client.setReadTimeout(10*1000);
		     		if(service.equals("DeDupe") || service.contains("DeDupe")) {
		         		response = webResource.accept("application/json").type("application/json").header("SOAPAction", "").post(ClientResponse.class,request);
		     		}else {
		         		response = webResource.accept("application/json").type("application/json").post(ClientResponse.class,request);
		     		}
		    	}
		    	catch (ClientHandlerException ch) {
		    		if(ch.getMessage().contains("connect timed out")) {
		    			Connect_Time_out = "599";
		    		}
		    		else if(ch.getMessage().contains("Read timed out")){
		    			Read_Time_Out = "598";
		    		}
		    	
		    	logger.error(ch);
			} catch (Exception e) {
		     			 logger.error(e);
		     		e.printStackTrace();
		     	  }
			
			
		    	if(response != null) {
		    		
		    		String output = response.getEntity(String.class);
		    		Status response_status = response.getResponseStatus();
		    		int response_code = response_status.getStatusCode();
		    		String code = String.valueOf(response_code);
		    		String description = prop.getProperty(code);
		    		map.put("apiURL", apiURL);
		    		map.put("request", request);
		    		map.put("response", output);
		    		map.put("response_status", String.valueOf(response_status));
		    		map.put("code", code);
		    		map.put("description", description);
		    		logger.info("Response_code	-	"+response_code);
		    		logger.info("Description	-	"+description);
		    		logger.info("=======================================================================================");
		    	}
		    	else {

		    		String output = "NA";
		    		String code = "";
		    		if(Connect_Time_out != "" && Connect_Time_out != null && Connect_Time_out.length() > 0) {
		    			code = Connect_Time_out;
		    		}
		    		else if(Read_Time_Out != "" && Read_Time_Out != null && Read_Time_Out.length() > 0) {
		    			code = Read_Time_Out;
		    		}
		    		else {
		    			code = connect_statuscode;
		    		}
		    		String description = prop.getProperty(code);
		    		logger.info("Response_code	-	"+code);
		    		logger.info("Description	-	"+description);
		    		logger.info("=======================================================================================");
		    		String output_1 = response.getEntity(String.class);
		    		Status response_status = response.getResponseStatus();
		    		int response_code = response_status.getStatusCode();
		    		String code_1 = String.valueOf(response_code);
		    		String description_1 = prop.getProperty(code);
		    		
		    		
		    		map.put("request", request);
		    		map.put("response", output_1);
		    		map.put("response_status", String.valueOf(response_status));
		    		map.put("code", code_1);
		    		map.put("description", description_1);

		    	}
			
		//			  System.out.println("map is  "+map);
       }catch(Exception e) {
    	   e.printStackTrace();
       }

		return map;
	}
}
