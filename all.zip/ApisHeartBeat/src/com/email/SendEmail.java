package com.email;
import java.util.*;  

import javax.mail.*;  
import javax.mail.internet.*;  
import javax.activation.*;  

import org.apache.log4j.Logger;

import com.api.ApiCalls;
  
public class SendEmail  
{  
	 final static Logger logger = Logger.getLogger(ApiCalls.class);
 public static void main(String [] args){  
 }
 public static void sendEmail(Map data_map) {    
 String to = "apisupport@federalbank.co.in";//change accordingly  
      String from = "apisupport@federalbank.co.in";//change accordingly  
//      String host = "localhost";//or IP address      
  		String host = "10.199.11.198";

      String msg = "";
     //Get the session object  
      Properties properties = System.getProperties();  
      properties.setProperty("mail.smtp.host", host);  
      Session session = Session.getDefaultInstance(properties);  
  
     //compose the message  
      try{  
         MimeMessage message = new MimeMessage(session);  
         message.setFrom(new InternetAddress(from));  
         message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
         message.setSubject("API testing");  
//         message.setText("Hello, this is example of sending email  "); 
         msg = "<html>";
         msg = "<body>";
         // Send message   
         msg += "<b>have a nice day!</b><br>";
         msg += "<font color=red>from api support</font>";
         msg += "<table width='100%' border='1' align='left'>"
        		+ "<th  align='left' style='background: #26ADE4;color: #fff;border: 1px solid #ddd;padding: 8px;'>S.No</th>"
        		+ "<th  align='left' style='background: #26ADE4;color: #fff;border: 1px solid #ddd;padding: 8px;'>API</th>"
         		+ "<th  align='left' style='background: #26ADE4;color: #fff;border: 1px solid #ddd;padding: 8px;'>Transaction</th>"
          		+ "<th  align='left' style='background: #26ADE4;color: #fff;border: 1px solid #ddd;padding: 8px;'>Response Code</th>"
         		+ "<th  align='left' style='background: #26ADE4;color: #fff;border: 1px solid #ddd;padding: 8px;'>Description</th>"
          		+ "<th  align='left' style='background: #26ADE4;color: #fff;border: 1px solid #ddd;padding: 8px;'>Display</th>";
         int serial_no = 0;
         for(int i=1;i<=data_map.size();i++) {
        	 serial_no++;
        	 HashMap<String, String> values = (HashMap<String, String>)data_map.get(i);
//        	 System.out.println("response_code =   "+values.get("response_code"));
//        	 System.out.println("api   =    "+values.get("api"));
//        	 System.out.println("transaction   =   "+values.get("transaction"));
//        	 System.out.println("Reason   	   =   "+values.get("reason")); 	 
        	 if(i%2==0) {
        		 msg += "<tr style='background-color: #f2f2f2;'>";
        	 }else {
        		 msg += "<tr style='background-color: #ddd;'>";
        	 }
        	 
        	String sNo = values.get("sNo");
        	 msg +="<td align='left' style='border: 1px solid #ddd;padding: 8px;'>"+serial_no+"</td>";
             msg +="<td align='left' style='border: 1px solid #ddd;padding: 8px;'>"+values.get("api")+"</td>";
             msg +="<td align='left' style='border: 1px solid #ddd;padding: 8px;'>"+values.get("transaction")+"</td>";
             msg +="<td align='left' style='border: 1px solid #ddd;padding: 8px;'>"+values.get("response_code")+"</td>";
             msg +="<td align='left' style='border: 1px solid #ddd;padding: 8px;'>"+values.get("reason")+"</td>";
             String request = values.get("request");       
             String modifyRequest = request.replaceAll("\"", "DQ0");
             String response = values.get("response");
         
//             String modifyflowerRequest = modifyRequest.replaceAll("\\{", "FS0");
//             String modifyReq = modifyflowerRequest.replaceAll("\\}", "BS0");
//             
//             
//             String modifyResponse = response.replaceAll("\"", "DQ0");
//             String modifyflowerResponse = modifyResponse.replaceAll("\\{", "FS0");
//             String modifyRes = modifyflowerResponse.replaceAll("\\}", "BS0");
//             
//             System.out.println("modifyRequest   "+modifyRequest);
//             System.out.println("modifyResponse   "+modifyResponse);
//             String url = "http://localhost:9063/Remittance_web/index.jsp?modifyReq="+modifyReq+"&modifyRes="+modifyRes;
            String url = "http://localhost:9063/Remittance_web/view.jsp?sNo="+sNo;
//            String html = "Test\n" + sNo + "\n<a href='http://test.com'>Test.com</a>";
             msg +="<td align='left' style='border: 1px solid #ddd;padding: 8px;'><a href='"+url+"'>download</a></td>";
         	 msg += "</tr>";      	
         }       
     	 msg += "</table>";
     	 msg += "</body>";

     	 msg +="</html>";
     	 message.setContent(msg, "text/html");
//         Transport.send(message);  
//         System.out.println("EMAIL sent successfully....");  
		 logger.info("EMAIL sent successfully....");	

      }catch (MessagingException mex) {
    	  
    	  logger.error(mex);
    	  mex.printStackTrace();}  
   }  
}  