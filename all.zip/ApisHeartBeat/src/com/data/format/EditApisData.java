package com.data.format;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DbConnection;

/**
 * Servlet implementation class EditApisData
 */
@WebServlet("/editApiData")
public class EditApisData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static java.sql.Timestamp getCurrentTimeStamp() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con = null;
		Statement stmt = null;
		DbConnection dbCon = new DbConnection();
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		   String date_time = dtf.format(now);
//		   System.out.println(dtf.format(now));  
		HttpSession session = request.getSession();
		
		String id = request.getParameter("api_id");
		String api_name = request.getParameter("api_name");
		String service = request.getParameter("service");
		String url = request.getParameter("url");
		String req = request.getParameter("request");
		String status = request.getParameter("status");
		
		try {
			con = dbCon.getConnection();
			stmt = con.createStatement();
			String query = "update MISAPP.APIC_HEARTBEAT_SERVICES set "
					+ "api_name='"+api_name.trim()+"',service='"+service.trim()+"',url='"+url.trim()+"'"
							+ ",request='"+req.trim()+"',status='"+status.trim()+"',LAST_MODIFIED_AT=TO_DATE('"+date_time+"', 'yyyy/mm/dd hh24:mi:ss') where id="+id;
		
//			System.out.println("query   "+query);
			int i = stmt.executeUpdate(query);
			if(i > 0) {
				session.setAttribute("editapis", "success");
//				System.out.println("updated successfully  ");
				response.sendRedirect("ApisCrud.jsp?success");
			}else {
				session.setAttribute("editapis", "failure");
				response.sendRedirect("ApisCrud.jsp?failure");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	
	}

}
