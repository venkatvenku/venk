package com.data.format;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;

import com.api.ApiCalls;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
//import com.email.SendEmail;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class SplitData {
	public void run() {
		
	}
	
	String filepath = "resources/statuscode.properties";
//	static String statusCodes = "/statuscode.properties";//statuscodes Data
	final static Logger logger = Logger.getLogger(SplitData.class);
public Map splitData(Map map_data) throws SocketTimeoutException {
	//reading status code from properties file
	ApiCalls apc = new ApiCalls();
	apc.setupHandler();
		Properties prop = new Properties();
		try {
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(filepath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	Map<Integer, HashMap<String,String>> final_status_map = new HashMap<Integer,HashMap<String,String>>();
//	System.out.println("MAP DATA SIZE IS    "+map_data.size());
	int count = 0;
//	ClientResponse response = null;
	Client client = Client.create();
	for(int k=1;k<=map_data.size();k++) {
		count++;
		HashMap<String, String> count_map = new HashMap<String,String>();
	String data = (String) map_data.get(k);
	String[] strArray = data.split("!@#");
	String db_serialNo = strArray[0];
	String api = strArray[1];
	String transaction = strArray[2];
	String api_url = strArray[3];
	String request = strArray[4];	
	String status = strArray[5];
	
	String API = api.trim();
	logger.info("API		-	"+API);
	String sNo = db_serialNo.trim();
	String TRANSACTION = transaction.trim();
	String API_URL = api_url.trim();
	String REQUEST = request.trim();
	String STATUS = status.trim();

	 logger.info("Transaction	-	"+TRANSACTION);
	if(STATUS.equalsIgnoreCase("y")) {			
	String connect_statuscode = apc.connectToURL(API_URL);
	
	String Connect_Time_out = "";
	String Read_Time_Out = "";
	ClientResponse response = null;
    	try {   	
    		
     		WebResource webResource = client.resource(API_URL);
     		client.setConnectTimeout(10*1000);//IN seconds i:e; 10 seconds
     		client.setReadTimeout(10*1000);
     		if(transaction.equals("DeDupe") || transaction.contains("DeDupe")) {
         		response = webResource.accept("application/json").type("application/json").header("SOAPAction", "").post(ClientResponse.class,REQUEST);
     		}else {
         		response = webResource.accept("application/json").type("application/json").post(ClientResponse.class,REQUEST);
     		}
    	}
    	catch (ClientHandlerException ch) {
    		if(ch.getMessage().contains("connect timed out")) {
    			Connect_Time_out = "599";
    		}
    		else if(ch.getMessage().contains("Read timed out")){
    			Read_Time_Out = "598";
    		}
    	
    		logger.error(ch);
	} catch (Exception e) {
     			 logger.error(e);
     		e.printStackTrace();
     	  }
	
if(response != null) {
//	System.out.println("respons esplit data class    "+response);
	String output = response.getEntity(String.class);
	Status response_status = response.getResponseStatus();
	int response_code = response_status.getStatusCode();
	String code = String.valueOf(response_code);
	String description = prop.getProperty(code);
	logger.info("Response_code	-	"+response_code);
	logger.info("Description	-	"+description);
	logger.info("=======================================================================================");
	count_map.put("sNo",sNo);
	count_map.put("api",API);
	count_map.put("transaction",TRANSACTION);
	count_map.put("API_URL",API_URL);
	count_map.put("response_code",code);
	count_map.put("reason",description);
	count_map.put("request",REQUEST);
	count_map.put("response",output);
	final_status_map.put(count,count_map);
}
else {
	String output = "NA";
	String code = "";
	if(Connect_Time_out != "" && Connect_Time_out != null && Connect_Time_out.length() > 0) {
		code = Connect_Time_out;
	}
	else if(Read_Time_Out != "" && Read_Time_Out != null && Read_Time_Out.length() > 0) {
		code = Read_Time_Out;
	}
	else {
		code = connect_statuscode;
	}
	String description = prop.getProperty(code);
	logger.info("Response_code	-	"+code);
	logger.info("Description	-	"+description);
	logger.info("=======================================================================================");
	count_map.put("sNo",sNo);
	count_map.put("api",API);
	count_map.put("transaction",TRANSACTION);
	count_map.put("API_URL",API_URL);
	count_map.put("response_code",code);
	count_map.put("reason",description);
	count_map.put("request",REQUEST);
	count_map.put("response",output);
	final_status_map.put(count,count_map);
}    
	} else {
		count--;
	}
	}
	logger.info("###########################################################################");	
	return final_status_map;
}
}
