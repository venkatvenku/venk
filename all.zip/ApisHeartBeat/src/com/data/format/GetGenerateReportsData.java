package com.data.format;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.dao.DbConnection;
import com.model.GenerateLogs;
import com.read.data.RunApiServices;

/**
 * Servlet implementation class GetGenerateReportsData
 */
@WebServlet("/GetGenerateReportsData")
public class GetGenerateReportsData extends HttpServlet {
	
	final static Logger logger = Logger.getLogger(GetGenerateReportsData.class);		

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<GenerateLogs> generateLogs = new ArrayList<GenerateLogs>();
		String requestFromDate = request.getParameter("fromdate");
		String requestToDate = request.getParameter("todate");
		
		
		
		Connection con = null;
		ResultSet rs = null;
		Statement stmt = null;

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");  
		LocalDateTime now = LocalDateTime.now();  
		String currentDate = dtf.format(now);
		String remReqDate = "";
		String query = "";
		if(requestFromDate == null || requestFromDate.length() == 0) {
			requestFromDate = currentDate;
		}else {			
			requestFromDate = requestFromDate.replaceAll("-", "");
			requestToDate = requestToDate.replaceAll("-", "");
		}
		query = "select * from MISAPP.APIC_SERVICE_AUDIT where APIC_LOGTIMESTAMP like '"+requestFromDate+"%'";

		int date = 0;
		if(requestToDate != null && requestToDate != "" && requestToDate.length() > 1) {
			date = Integer.parseInt(requestToDate);
			date++;
			query = "select * from MISAPP.APIC_SERVICE_AUDIT where APIC_LOGTIMESTAMP between '"+requestFromDate+"%' and '"+requestToDate+"%' order by APIC_LOGTIMESTAMP";
		}
//		System.out.println("query  "+query);
		DbConnection dbc = new DbConnection();
		int sNo = 0;
		try {
		con = dbc.getConnection();

		stmt = con.createStatement();
		rs = stmt.executeQuery(query);
		while(rs.next()) {
			GenerateLogs genlog = new GenerateLogs();
			
			genlog.setCALLBACK_FLAG(rs.getString("CALLBACK_FLAG"));   
			genlog.setCALLBACK_PAYLOAD(rs.getString("CALLBACK_PAYLOAD"));  
			
//			System.out.println("call back flasg  "+)
			
			genlog.setAPIC_LOGPOINTID(rs.getString("APIC_LOGPOINTID"));   
			genlog.setAPIC_GWYTRANID(rs.getString("APIC_GWYTRANID"));  
			genlog.setAPIC_LOGSOURCE(rs.getString("APIC_LOGSOURCE")); 

			genlog.setAPIC_TRANDURATION(rs.getString("APIC_TRANDURATION"));		
			
			String ApiName = rs.getString("APIC_APINAME");
			if(ApiName == null ) {
				ApiName = "NA";
			}
			genlog.setAPIC_APINAME(ApiName);
			
			genlog.setAPIC_APIVERSION(rs.getString("APIC_APIVERSION"));   
			genlog.setAPIC_INTERFACENAME(rs.getString("APIC_INTERFACENAME"));   

			genlog.setAPIC_QUERYPARAM(rs.getString("APIC_QUERYPARAM"));
			genlog.setAPIC_HTTPREQUESTHEADERS(rs.getString("APIC_HTTPREQUESTHEADERS"));   
			genlog.setAPIC_HTTPRESPONSEHEADERS(rs.getString("APIC_HTTPRESPONSEHEADERS"));  
			genlog.setAPIC_ORIGREQUESTPAYLOAD(rs.getString("APIC_ORIGREQUESTPAYLOAD"));   

			genlog.setAPIC_FINALRESPONSEPAYLOAD(rs.getString("APIC_FINALRESPONSEPAYLOAD"));
			genlog.setAPIC_ERRORRESPONSEPAYLOAD(rs.getString("APIC_ERRORRESPONSEPAYLOAD"));   
			genlog.setAPIC_MISC(rs.getString("APIC_MISC"));   
			genlog.setAPIC_DEVORGNAME(rs.getString("APIC_DEVORGNAME"));   			 
			
			String ClientAppName = rs.getString("APIC_CLIENTAPPNAME");
			if(ClientAppName == null ) {
				ClientAppName = "NA";
			}
			genlog.setAPIC_CLIENTAPPNAME(ClientAppName);
			genlog.setAPIC_APICGWYID(rs.getString("APIC_APICGWYID"));   
			genlog.setAPIC_OPERATIONID(rs.getString("APIC_OPERATIONID"));   
			
			String catalog = rs.getString("APIC_CATALOG");
			if(catalog == null ) {
				catalog = "NA";
			}
			genlog.setAPIC_CATALOG(catalog);   
			
			
			genlog.setAPIC_APICINURL(rs.getString("APIC_APICINURL"));
			genlog.setAPIC_APICOUTURL(rs.getString("APIC_APICOUTURL"));  
			String StatusCode = rs.getString("APIC_STATUSCODE");
			if(StatusCode == null ) {
				StatusCode = "NA";
			}
			genlog.setAPIC_STATUSCODE(StatusCode); 
			String StatusMesg = rs.getString("APIC_STATUSMSG");
			if(StatusMesg == null ) {
				StatusMesg = "NA";
			}
			genlog.setAPIC_STATUSMSG(StatusMesg);
			String logtime = rs.getString("APIC_LOGTIMESTAMP");
			String newLogTime = logtime.substring(0, logtime.indexOf("."));
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
			        String dateInString = "";
			        SimpleDateFormat formatter1 = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");

			        try {
			            Date date1 = formatter.parse(newLogTime);
			            dateInString = formatter1.format(date1);			            
			            genlog.setAPIC_LOGTIMESTAMP(dateInString);
			        } catch (ParseException e) {
			            e.printStackTrace();
			        }
			
			generateLogs.add(genlog);
//			System.out.println(genlog.toString());
		}
		}catch(Exception e) {
			logger.error(e);
//			e.printStackTrace();
		}
		   request.setAttribute("products", generateLogs); // Will be available as ${products} in JSP
           request.getRequestDispatcher("generatereports.jsp").forward(request, response);
	}

}
