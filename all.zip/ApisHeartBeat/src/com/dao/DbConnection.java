package com.dao;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DbConnection {
	final static Logger logger = Logger.getLogger(DbConnection.class);
	//FOR Oracle db connection		
	public Connection getConnection() {
		  Connection connection = null;		
		  String driverClass = "";
		  String connection_URL = "";
		  String userName = "";
		  String password = "";
		  Properties prop = new Properties();
	    	String filepath = "resources/dbConnection.properties";
		  try {
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(filepath));
			driverClass = prop.getProperty("driverClassName");
			connection_URL = prop.getProperty("url");
			userName = prop.getProperty("username");
			password = prop.getProperty("password");
			
		} catch (IOException e1) {
			logger.error(e1.getMessage());
		}
		  
		 try {
	            Class.forName(driverClass);
	            connection = DriverManager.getConnection(connection_URL,userName,password);
	        }
	        catch(ClassNotFoundException cnfex) {
	        	logger.error("Problem in loading or registering ORACLE JDBC driver",cnfex);
	        } catch (SQLException e) {
				logger.error(e.getMessage());
			}
		return connection;
	}
	public static void main(String[] args) {
//		
	}
}
