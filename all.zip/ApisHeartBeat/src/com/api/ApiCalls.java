package com.api;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.security.cert.X509Certificate;
import java.io.IOException;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

 public class ApiCalls
{
	 final static Logger logger = Logger.getLogger(ApiCalls.class);
//	 static
	 
	 public ApiCalls(final String api_URL,String trust_strore_location,String trust_store_password,String Key_store_location,String key_store_password)
		{
	
//		 
//		 System.out.println("API URL   =   "+api_URL);
//		 System.out.println("TRUST STORE LOCATION   =   "+trust_strore_location);
//		 System.out.println("KEY STORE LOCATION     =   "+Key_store_location);
//		 System.out.println("TRUST STORE PASSWORD   =   "+trust_store_password);
//		 System.out.println("KEY STORE PASSWORD     =   "+key_store_password);
		 
		 logger.info("API URL   =   "+api_URL);
		 logger.info("TRUST STORE LOCATION   =   "+trust_strore_location);
		 logger.info("TRUST STORE PASSWORD   =   "+trust_store_password);
		 logger.info("KEY STORE LOCATION     =   "+Key_store_location);
		 logger.info("KEY STORE PASSWORD     =   "+key_store_password);
		 
			System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
			System.setProperty("https.protocols", "TLSv1.2");
			
			//trust store
			System.setProperty("javax.net.ssl.trustStore", trust_strore_location);
			System.setProperty("javax.net.ssl.trustStorePassword", trust_store_password);
			
			//key store
			System.setProperty("javax.net.ssl.keyStore",Key_store_location);
	        System.setProperty("javax.net.ssl.keyStorePassword", key_store_password);
			
	        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
        };
 
        // FOR Disabling the Truststore validation the all-trusting trust manager
//        SSLContext sc = null;
//		try {
//			sc = SSLContext.getInstance("SSL");
//		} catch (NoSuchAlgorithmException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        try {
//			sc.init(null, trustAllCerts, new java.security.SecureRandom());
//		} catch (KeyManagementException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        
			javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
					new javax.net.ssl.HostnameVerifier() {
						int i = api_URL.indexOf("/");
						int k = api_URL.lastIndexOf(":");
						String ip_address = api_URL.substring(i+2, k);
						public boolean verify(String hostname,
								javax.net.ssl.SSLSession sslSession) {
							if (hostname.equals(ip_address)) {
								return true;
							}
							return false;
						}
					});
			
			
		}
	 public ApiCalls() {
		// TODO Auto-generated constructor stub
	}
//main method
   public static void main (String [] args) { 
	   
   }
    public static void setupHandler()
   {
     java.util.Properties p = System.getProperties();
     String s = p.getProperty("java.protocol.handler.pkgs");
     if (s == null)
       s = "weblogic.net";
     else if (s.indexOf("weblogic.net") == -1)
       s += "|weblogic.net";
     p.put("java.protocol.handler.pkgs", s);
     System.setProperties(p);
   }
    
    public static String connectToURL(String theURLSpec)
   {
    	String statusCode = "";
     try {
       URL theURL = new URL(theURLSpec);
       URLConnection urlConnection = theURL.openConnection();
       HttpURLConnection connection = null;
       if (!(urlConnection instanceof HttpURLConnection))
       {
    	 logger.warn("The URL is not using HTTP/HTTPS: " +theURLSpec);
//         return;
       }
       connection = (HttpURLConnection) urlConnection;
       connection.connect();
     }
     catch (IOException ioe)
     {
    	 System.out.println("message   "+ioe.getMessage());
    	 if(ioe.getMessage().contains("Connection refused")) {
    		 statusCode = "502";
    	 }
//    	 logger.error("Failure processing URL:  ", ioe);
//    	 System.out.println("failure processing url   "+theURLSpec);
//       ioe.printStackTrace();
     }
     return statusCode;
   }
    
    public static ClientResponse getResponse(String API,String transaction,String Api_url,String request_data) throws SocketTimeoutException{
    	ClientResponse response = null;
    	try {
     		Client client = Client.create();		
     		WebResource webResource = client.resource(Api_url);
     		client.setConnectTimeout(10);
     		client.setReadTimeout(1000);
//     		client.setConnectTimeout(interval);
     		if(transaction.equals("DeDupe") || transaction.contains("DeDupe")) {
         		response = webResource.accept("application/json").type("application/json").header("SOAPAction", "").post(ClientResponse.class,request_data);
     		}else {
         		response = webResource.accept("application/json").type("application/json").post(ClientResponse.class,request_data);
     		}
//     		response = webResource.accept("application/json").type("application/json").post(ClientResponse.class,request_data);
    	}
    	catch (ClientHandlerException ch) {
  		  System.out.println("inside clien handler exception   "+ch.getLocalizedMessage()+" AND MESSAGE   "+ch.getMessage());
  		ch.printStackTrace();
  	  } 
   	catch (Exception e) {
     			 logger.error(e);
     		e.printStackTrace();
     	  }
    	return response;
    }
}