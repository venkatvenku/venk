package sample;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.dao.DbConnection;

public class Demo {
public static void main(String[] args) {
	
	try {
	DbConnection dbc = new DbConnection();
	

	
	
	Connection con = null;
	Statement stmt = null;
	con = dbc.getConnection();
	PreparedStatement pstmt = null;
	
	System.out.println("connection   "+con);
	stmt = con.createStatement();

	String sql = "truncate table MISAPP.MARCHENT_USERS";
//	String sql = "select * from MISAPP.";
//	String sql = "INSERT INTO MISAPP.APIC_HEARTBEAT_DAILY_LOGS(id,api_name,service,url,request,response,response_code,resp_desc) VALUES (?,?,?,?,?,?,?,?)";
//	ResultSet rs = stmt.executeQuery(sql);
	int i = stmt.executeUpdate(sql);
//	while(rs.next()) {
//		System.out.println(rs.getString(1));
//	}
//	
//	pstmt = con.prepareStatement(sql);
//	pstmt.setInt(1, 1);
//
//		pstmt.setString(2, "remittance");
//		pstmt.setString(3, "ft");
//		pstmt.setString(4, "http://14.140.230.181:669/Transafer_FT");
//		pstmt.setString(5, "ABC:123");
//		pstmt.setString(6, "RESPONSE CODE");
//		pstmt.setInt(7, 123);
//		pstmt.setString(8, "SUCCESS");
////		pstmt.setString(8, date_time);
//		int t = pstmt.executeUpdate();
	
	
	int t = stmt.executeUpdate(sql);
	
	System.out.println("sql   "+sql);
	
	if(t > 0) {
		System.out.println("success   ");
	}
	else {
		System.out.println("failure   ");
	}
	
	}catch(Exception e) {
		e.printStackTrace();
	}
	
}
}
