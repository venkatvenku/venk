package ldap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class GetExpiryDate {
 static String ldapSearchBase = "DC=federalbank,DC=co,DC=in";
 private static DirContext ctx = null;
 private static DirContext getActiveDirectoryContext() throws Exception {

   final Properties properties = new Properties();
  properties.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
  properties.put(Context.PROVIDER_URL,"ldap://10.199.11.49:389");
  properties.put(Context.SECURITY_AUTHENTICATION,"simple");
  properties.put(Context.SECURITY_PRINCIPAL, "apisupport@federalbank.co.in");
  properties.put(Context.SECURITY_CREDENTIALS,"federal@1234");
  return new InitialDirContext(properties);

  }
 public void getGroupUsers(String searchBase, String searchFilter, String returnedAttrs[], int maxResults)
 {
  Hashtable userEntries = null;
  String member="";
  try{
   SearchControls searchCtls = new SearchControls();
   searchCtls.setSearchScope(SearchControls.ONELEVEL_SCOPE);       
   searchCtls.setReturningAttributes(returnedAttrs);
   ctx=getActiveDirectoryContext();
   try{
    System.out.println("Search Base: "+searchBase);
    System.out.println("Search Filter: "+searchFilter);
    NamingEnumeration users = ctx.search(searchBase, searchFilter, searchCtls);
    if(users.hasMoreElements() == false){
    System.out.println("Not find any object with this filter " + searchFilter + " and searchBase " + searchBase);
    }
    
    int k = 0;
    String attValue = "";
    userEntries = new Hashtable();
    while (users.hasMoreElements()){
     if(k >= maxResults)
      break;           
     SearchResult sr = (SearchResult)users.next();
     Attributes attrs = sr.getAttributes();
     if (attrs.size() == 0){
      System.out.println("Could not find attribute " + returnedAttrs[0] + " for this object.");
     }else{
     
      try{     
          GetExpiryDate ged = new GetExpiryDate();

    	  String lastSetPassword = "";
    	  Pattern pattern = Pattern.compile(".*[a-zA-Z]+.*");
       for (NamingEnumeration ae = attrs.getAll();ae.hasMore();){ 
        Attribute attr = (Attribute)ae.next();                  
        String id = attr.getID();
        for (NamingEnumeration e = attr.getAll();e.hasMore();){                      
         attValue = (String)e.next();
        	   Matcher matcher = pattern.matcher(attValue);
        	   if (matcher.matches()) {
        		   String user_name = attValue;
             	  String expiry_date = ged.passwordExpiryDate(lastSetPassword);
                  System.out.println(user_name+"   -    password will expire on "+expiry_date);

              } else {
            	lastSetPassword = attValue;
            	}
         }
       }
      }catch(NamingException e){
       System.out.println("Problem listing membership:"+e);            
      }     
     }
     k++;
    }
   }catch (NamingException e){
    System.out.println("Problem searching directory: "+e);            
   }       
   ctx.close();
   ctx=null;   
  }catch (Exception namEx){
   System.out.println("Exception while fetching the users from LDAP::"+namEx);        
  }     
  
 }
 //password expiry dates
 public String passwordExpiryDate(String LDAPDate) {
	 	Date dNow = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		 long pwdSetDate = java.lang.Long.parseLong(LDAPDate);		 
		 Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
		    c.clear();
		    c.set(2016, 11, 22, 12, 33, 24);
		  /*  c.set(2016, 11, 22);*/
		    long t1 = c.getTimeInMillis();
		    c.set(1601, 0, 1);
		    long t2 = c.getTimeInMillis();
		    long ldap = (t1 - t2) * 10000+11644473600000L;
//		    System.out.println("LDAP:"+ldap);
		    
		 long timeAdjust=11644473600000L;
		 Date pwdSet = new Date(pwdSetDate/10000-timeAdjust); 
		 //System.out.println(pwdSet);
		 // Date pwdSet = new Date(java.lang.Long.parseLong(LDAPDate)/10000-11644473600000L); 
	     DateFormat mydate = new SimpleDateFormat("dd/MM/yyyy");
		/*System.out.println(
				"Last Password change On = " + mydate.format(pwdSet));*/
		 long diff =  dNow.getTime()-pwdSet.getTime() ;
		 int day=(int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		/*System.out.println("Password Set Duration :"+day+" days");*/
		 int days2ExpirePass=45-day;
//		System.out.println(" Password will expire on :"+days2ExpirePass+" days");
		return String.valueOf(days2ExpirePass);		
 }
 
 public static void main(String args[]) throws Exception{
  GetExpiryDate gug = new GetExpiryDate();
  String returnedAttrs[] = {"cn","pwdLastSet"};  //"memberOf", "name"
  String searchFilter="CN=OutsourcedUsersGroup";
  gug.getGroupUsers("OU=AppUsers,OU=FederalUsers,DC=federalbank,DC=co,DC=in","(objectClass=User)", returnedAttrs, Integer.parseInt("2000"));
 }
}