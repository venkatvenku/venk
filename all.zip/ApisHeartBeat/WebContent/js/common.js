$(function(){
		 
		// flags for menu selection
					var leftmenu = 1;
					var hormenu = 0;
					if (leftmenu == 1 && hormenu == 1) {
						$('.nav-horz').show();
						$('#showLeftPush').show();
						$('.navbar-side').css({left: '0px'});
						$('#page-wrapper').css({'margin-left' : '198px'});
					}
					if (leftmenu == 0 && hormenu == 0) {
						$('.nav-horz').hide();
						$('#showLeftPush').hide();
					}
					if (leftmenu == 0 && hormenu == 1) {
						$('.nav-horz').show();
						$('#showLeftPush').hide();
						$('.navbar-side').css({left: '-198px'});
						$('#page-wrapper').css({'margin-left' : '0px'}); 
					}
					if (leftmenu == 1 && hormenu == 0) {
						$('.nav-horz').hide();
						$('#showLeftPush').show();
						$('.navbar-side').css({left: '0px'});
						$('#page-wrapper').css({'margin-left' : '198px'}); 
					}
					if (document.documentElement.clientWidth < 900) {
						$('.nav-horz').hide();
					}
//		 		 	sidebar-toggle
				 	$("#toggle").click(function(){
				 		 $(".toggle").toggleClass("closed");
				 		if($(this).hasClass('closed')){
							$('.navbar-side').animate({left: '0px'});
							$(this).removeClass('closed');
							$('#page-wrapper').animate({'margin-left' : '198px'});
						}
				 		else{
						    $(this).addClass('closed');
							$('.navbar-side').animate({left: '-260px'});
							$('#page-wrapper').animate({'margin-left' : '0px'}); 
						}
				    });
//		 		 	horizontal menu toggle
						$("#chkMenu").click(function () {
				 		  if ($(this).is(":checked")) {
				                $(".nav-horz").addClass('show');
				            } else {
				                $(".nav-horz").removeClass('show');
				            }
				        });
						 var main_url1 = $(location).attr("href").split('/');
						 var main_url2 =document.URL.substr(0,document.URL.lastIndexOf('/'));
						 var array2 = main_url2.split('/');
						 var main_url = $(main_url1).not(array2).get();
						 $(".nav-horz li").each(function() {
							var active_nav = $(this);
							 $(this).children("ul").children("li").each(function(){
								var nav_url = $(this).children("a").attr("href");
								if(nav_url == main_url){
									active_nav.addClass("active");
									$(this).addClass("active");
								}
							 });
							 $(this).each(function(){
									var nav_url = $(this).children("a").attr("href");
									if(nav_url == main_url){
										active_nav.addClass("active");
										$(this).addClass("active");
									}
								 });
					    });

						$("#main-menu").children("li").each(function() {
							var active_menu = $(this);
							$(this).children("ul").children("li").each(function() {
								var side_url = $(this).children("a").attr("href");
								 if(side_url == main_url){
									active_menu.addClass("active");
									$(this).addClass("active");
									//active_menu.children("ul").css('display','block')
								} 
							}); 
							$(this).each(function(){
								var nav_url = $(this).children("a").attr("href");
								if(nav_url == main_url){
									active_menu.addClass("active");
									$(this).addClass("active");
								}
							 });
							
					    });
				
			}); 
