
 function selected() {
 	var value = document.getElementById("selectvalue").value;
 	  var xhttp = new XMLHttpRequest();
 	  xhttp.onreadystatechange = function() {
 	    if (this.readyState == 4 && this.status == 200) {
 	      document.getElementById("demo").innerHTML =
 	      this.responseText;
 	    }
 	  };
 	  xhttp.open("GET", "ajax.jsp?name="+value, true);
 	  xhttp.send();
 }
 
// for loading div
 function loadingDiv() {
	 var value = document.getElementById("selectvalue").value;
	 if(value != null & value != ""){
		 document.getElementById('loadingDiv').style.display = "block";
	 }
}
 
//for loading div for backend api reports
 function loadingDiv_backend() {
	 var value = document.getElementById("selectvalue").value;
	 var time_value = document.getElementById("timeinterval").value;
	 if(value != null & value != "" && time_value != null && time_value != ""){
		 document.getElementById('loadingDiv').style.display = "block";
	 }
}
 
 
 //for generate reports jsp page
 function loadingDiv_1() {	 	 
//	 alert("in loading_div1");
	 var value = document.getElementById("fdate").value;
	 if(value != null & value != ""){
		 document.getElementById('loadingDiv').style.display = "block";
	 }
}
 
// for api curd
 function loadapi_ID(api_id) {
	  var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (this.readyState == 4 && this.status == 200) {
	    }
	  };
	  xhttp.open("GET", "ajax.jsp?delete_api_id="+api_id, true);
	  xhttp.send();
	}
 
 //for generate reports jsp page
