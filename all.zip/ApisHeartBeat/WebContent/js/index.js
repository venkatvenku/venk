//opening model box and set session
function myFunction(data_id) {
var url="ajax.jsp?id="+data_id; 
if(window.XMLHttpRequest){  
request=new XMLHttpRequest();  
}  
else if(window.ActiveXObject){  
request=new ActiveXObject("Microsoft.XMLHTTP");  
}    
try{  
request.onreadystatechange=getInfo;  
request.open("GET",url,true);  
request.send();  
}catch(e){alert("Unable to connect to server");}  
}    
function getInfo(){  
if(request.readyState==4){  
var val=request.responseText;  
}  
var modal = document.getElementById('myModal');
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];
modal.style.display = "block";
span.onclick = function() {
modal.style.display = "none";
	    }
}

//password validation
function password_validate() {
	//alert("isiude js function");
    var password = document.getElementById("password").value;
    var confirm_password = document.getElementById("confirm_password").value;
    if(password != confirm_password)   {
		document.getElementById('pass').innerHTML="<font color=red>passwords are mis matched</font>";  
		 document.frm.confirm_password.setCustomValidity("Password and confirm Password must be same");
	  } 
	  else  {
			document.getElementById('pass').innerHTML="<font color=green>passwords matched</font>";  
		  document.frm.confirm_password.setCustomValidity('');
	  }
}//passowrd validation

//finiding duplicate elements
function duplicateFunction() {
	var name=document.getElementById("unique_name").value; 
	var table_name=document.frm.table_name.value;
	var url="ajax.jsp?name="+name+"&table_name="+table_name; 
	if(window.XMLHttpRequest){  
	request=new XMLHttpRequest();  
	}  
	else if(window.ActiveXObject){  
	request=new ActiveXObject("Microsoft.XMLHTTP");  
	}    
	try{  
	request.onreadystatechange=getInfo_1;
	request.open("GET",url,true);  
	request.send();  
	}catch(e){alert("Unable to connect to server");}  
	}    
	function getInfo_1(){
	if(request.readyState==4){  
	var val=request.responseText;  
	document.getElementById('amit').innerHTML=val;  
	}  
	
}
//	for image changing in sort symbols
	
	/*function diffImage(img) 
	{
	   if(img.src.match(/sort22/)) img.src = "images/sort2.jpg";
	   else img.src = "images/sort22.jpg";
	}*/
	
	

//	for reports_1 page showing and hiding div when option selected
	function admSelectCheck(nameSelect)
	{
	    console.log(nameSelect);
	    if(nameSelect){
	        admOptionValue = document.getElementById("admOption").value;
	        if(admOptionValue == nameSelect.value){
	            document.getElementById("admDivCheck").style.display = "block";
	        }
	        else{
	            document.getElementById("admDivCheck").style.display = "none";
	        }
	    }
	    else{
	        document.getElementById("admDivCheck").style.display = "none";
	    }
	}
	
	//for end batch_date
	function enddate(){
		var start_date=document.frm.start_date.value;
		alert("start_date "+start_date);
		var url="ajax.jsp?start_date="+start_date; 
		if(window.XMLHttpRequest){  
		request=new XMLHttpRequest();  
		}  
		else if(window.ActiveXObject){  
		request=new ActiveXObject("Microsoft.XMLHTTP");  
		}    
		try{  
		request.onreadystatechange=getInfo_start_date_1;
		request.open("GET",url,true);  
		request.send();  
		}catch(e){alert("Unable to connect to server");}  
		}    
		function getInfo_start_date_1(){
		if(request.readyState==4){  
		var val=request.responseText;  
		document.getElementById('start_date_1').innerHTML=val;  
		}  
	}
		//for edit end date
		function edit_enddate(){
			var start_date=document.frm.start_date.value;
			var batch_id=document.frm.batch_id.value;
//			alert("start_date "+start_date);
//			alert("batch -id  "+batch_id);
			var url="ajax.jsp?edit_start_date="+start_date+"&edit_batch_id="+batch_id; 
			if(window.XMLHttpRequest){  
			request=new XMLHttpRequest();  
			}  
			else if(window.ActiveXObject){  
			request=new ActiveXObject("Microsoft.XMLHTTP");  
			}    
			try{  
			request.onreadystatechange=getInfo_start_date;
			request.open("GET",url,true);  
			request.send();  
			}catch(e){alert("Unable to connect to server");}  
			}    
			function getInfo_start_date(){
			if(request.readyState==4){  
			var val=request.responseText;  
			document.getElementById('edit_start_date').innerHTML=val;  
			}  
		}

			//pdf format
			function pdf_report(){
				$('#myModal').modal('hide');
			}
			
			
			
			//avarage investable maount
			
			function ShowInvestor_type(chkPassport){       
//			 	alert("venlkakt in  ShowInvestor_type   "+chkPassport);
			    var type = document.frm.type.value;
//			     alert("type is   "+type);

				var url="ajax.jsp?investor_type="+type; 
				if(window.XMLHttpRequest){  
				request=new XMLHttpRequest();  
				}  
				else if(window.ActiveXObject){  
				request=new ActiveXObject("Microsoft.XMLHTTP");  
				}    
				try{  
				request.onreadystatechange=getInfo_investor_type;
				request.open("GET",url,true);  
				request.send();  
				}catch(e){alert("Unable to connect to server");}  
				}    
				function getInfo_investor_type(){
				if(request.readyState==4){  
				var val=request.responseText;  
				document.getElementById('investor_type').innerHTML=val;  
				}  
				
			}
				
				function avg_function(){
					var investable_amount = document.frm.investable_amount.value;
					var avg_investment_amount = document.frm.avg_investment_amount.value;
//			 	     alert("investable_amount is   "+investable_amount);
//			 	     alert("avg_investment_amount is   "+avg_investment_amount);
				     var invest = parseInt(investable_amount);
				     var avg_invest = parseInt(avg_investment_amount);
				     if(avg_invest>invest) {
				    	 alert("Average investable amount must be less than investable amount");
				    	 return false;
				    	 
				     }

				}
				//for editing details
				
					   
				
				
				function ShowInvestor_type_edit(chkPassport){       
				    var type = document.frm.type.value;
			if(type == "Company") {
			    document.getElementById("company_div").style.display = "none";
			    document.getElementById("individual_type").style.display = "none";
				document.getElementById("company_type").style.display = "block";
			}
			else {
			    document.getElementById("company_div").style.display = "block";
			    document.getElementById("individual_type").style.display = "block";
				document.getElementById("company_type").style.display = "none";
			}
					var url="ajax.jsp?investor_type="+type; 
					if(window.XMLHttpRequest){  
					request=new XMLHttpRequest();  
					}  
					else if(window.ActiveXObject){  
					request=new ActiveXObject("Microsoft.XMLHTTP");  
					}    
					try{  
					request.onreadystatechange=getInfo_investor_type;
					request.open("GET",url,true);  
					request.send();  
					}catch(e){alert("Unable to connect to server");}  
					}    
					function getInfo_investor_type(){
					if(request.readyState==4){  
					var val=request.responseText;  
					document.getElementById('investor_type').innerHTML=val;  
					}  
					
				}

					
					//code fro radio biuttons in invetspr registartion page
					function ShowInvestor_type_register(chkPassport){ 
						//alert("venkat" );
						var type = document.frm.type.value;
						//alert("type "+type);
						if(type=='individual') {
							document.getElementById("individual_type").style.display = "block";
							document.getElementById("company_type").style.display = "none";
						}
						else {
							document.getElementById("individual_type").style.display = "none";
							document.getElementById("company_type").style.display = "block";

						}
							var url="ajax.jsp?investor_type_register="+type;
							
							if(window.XMLHttpRequest){  
							request=new XMLHttpRequest();  
							}  
							else if(window.ActiveXObject){  
							request=new ActiveXObject("Microsoft.XMLHTTP");  
							}    
							try{  
							request.onreadystatechange=getInfo_investor_type_register;
							request.open("GET",url,true);  
							request.send();  
							}catch(e){alert("Unable to connect to server");}  
							}    
							function getInfo_investor_type_register(){
							if(request.readyState==4){  
							var val=request.responseText;  
							document.getElementById('investor_type').innerHTML=val;  
							}  
							
						}
							
							//for getting idea id to change status of the company ideas