package com.rest;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.json.JSONArray;
import org.json.JSONObject;


@Path("/send")
public class SendLogData {
	@POST
	@Path("/logdata")
	public String Open(InputStream incomingData) {	
		
		StringBuilder crunchifyBuilder = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				crunchifyBuilder.append(line);
			}
		} catch (Exception e) {
			System.out.println("Error Parsing: - ");
		}
		String output = crunchifyBuilder.toString();
//		JSONObject jObject  = new JSONObject(output);
		if(output!=null) {
			Email email = new Email();
			email.send_email(output);
		}
//		String str=(String) jObject.get("abc");
	System.out.println("abc "+output);
	return "success";	
	}
}
