package com.rest;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
 
public class Email {
 
    public void sendHtmlEmail(String host, String port,
            final String userName, final String password, String toAddress,
            String subject, String message) throws AddressException,
            MessagingException {
 
        // sets SMTP server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", "false");
        properties.put("mail.smtp.starttls.enable", "true");
 
        // creates a new session with an authenticator
        Authenticator auth = new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(userName, password);
            }
        };
 
        Session session = Session.getInstance(properties, auth);
 
        // creates a new e-mail message
        Message msg = new MimeMessage(session);
 
        msg.setFrom(new InternetAddress(userName));
        InternetAddress[] toAddresses = { new InternetAddress(toAddress) };
        msg.setRecipients(Message.RecipientType.TO, toAddresses);
        msg.setSubject(subject);
        msg.setSentDate(new Date());
        // set plain text message
        msg.setContent(message, "text/html");
 
        // sends the e-mail
        Transport.send(msg);
 
    }
 
    /**
     * Test the send html e-mail method
     *
     */
    
    public void send_email(String log_data) {
		//read eamil credentials from resources properties   
    	// SMTP server information
    	//String host = "smtp.gmail.com";
    	String host = "10.199.11.198";
    	String port = "25";
    	String mailFrom = "apisupport@federalbank.co.in";
    	String password = "Federal@123";
    	String mailTo = "apisupport@federalbank.co.in";
        
        String subject = "Cerificate Expire Report for UAT";
        String message = "<i>Greetings!</i><br>";
        message += "<b>have a nice day!</b><br>";
        message += "<font color=red>from api support</font>";
        message += "<table width='100%' border='1' align='center'><th>Client Name</th><th>Environment</th><th>Expiry Date</th>";

		Set<String> set = new HashSet<String>();
			try {				
							
				Pattern p = Pattern.compile("'([^' ]+)'");//it will get the data in between the single colons
				Matcher matcher = p.matcher(log_data);
				int count =0;
				String data= "";				
				while (matcher.find()) {
					count++;
				    String match = matcher.group();				  
				    data = data+match+"#"; //based on the hash(#) we can split the values				   
				    if(count%3 == 0) {
				    	 set.add(data);
				    	 data="";  
				    }
				}			
			} catch (Exception e) {
				e.printStackTrace();
			}
 
//        ================================
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
        
        System.out.println("list value is   "+set);
        for(String str : set) {
        	
        	String s1 = str.replaceAll("'", "");
        	String[] arr = s1.split("#");
      	  message += "<tr>";
      	  int k = 0;
        	for(int i=0;i< arr.length;i++) {
        		System.out.println("I VALUE BEFORE  IS   "+i+"arr value   "+arr[i]);
        		k++;
        		System.out.println("arr.length  "+arr.length);
        		if(arr.length%k == 0 && k>1) {
        			System.out.println("i value "+i+" and  "+arr[i]);
        			String sample = (String)arr[i];
        			String[] date = sample.split("T");
        			for(int m=0;m<date.length;m++) {
        				System.out.println("date   "+date[m]);
        				String dt = (String)date[0];
        				try {
							  Date date_1 = format1.parse(dt);
							  System.out.println(format2.format(date_1));
							  message +="<td align='center'>"+format2.format(date_1) +"  "+ date[1]+"</td>";
							  break;
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}       		      
        			}       			
        		}
        		
        		else if(i==1) {
        			System.out.println("I VALUE after  IS   "+arr[i]);
        			message +="<td align='center'>UAT</td>";
        		}
        		else {
        			
        			if(arr[i].contains("_uat") || arr[i].contains("_UAT")) {
        				String value = arr[i].replace("_uat", "");
        				message +="<td align='center'>"+value+"</td>";
        			}
        			else {
        				message +="<td align='center'>"+arr[i]+"</td>";
        			}
        		
        		}
        	}
        	  message += "</tr>";
        	System.out.println(" k value is    "+k);       	
        }  
        message += "</table>";
        
        
        Email mailer = new Email();
        try {
            mailer.sendHtmlEmail(host, port, mailFrom, password, mailTo,
                    subject, message);
            System.out.println("Email sent.");
        } catch (Exception ex) {
            System.out.println("Failed to sent email.");
            ex.printStackTrace();
        }
    
    }
    public static void main(String[] args) {}
}