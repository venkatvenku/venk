//for laodin div
function loadin_div() {
//	alert("open ");
	 var from_date = document.getElementById("datepicker-13").value;
	 var to_date = document.getElementById("datepicker-14").value;
//	 alert("from_date    "+from_date+"   to_date    "+to_date);
	 if(from_date != null & from_date != "" & to_date != null & to_date != ""){
		 document.getElementById('loadingDiv').style.display = "block";
	 }
//	$("#loadingDiv").show();
}


function loadvirtual_ID(virtual_id) {
//     	  alert("virtual is   "+virtual_id);
    	  var xhttp = new XMLHttpRequest();
    	  xhttp.onreadystatechange = function() {
    	    if (this.readyState == 4 && this.status == 200) {
    	      document.getElementById("demo").innerHTML = virtual_id;
    	    }
    	  };
//     	  alert("inside  ");
    	  xhttp.open("GET", "ajax.jsp?virtual_id="+virtual_id, true);
//     	  alert("out side");
    	  xhttp.send();
    	}
      
      //get Device id for active and deactive status
      function getDeviceId(device_id) {
//     	  alert("device_id is   "+device_id);
    	  var xhttp = new XMLHttpRequest();
    	  xhttp.onreadystatechange = function() {
    	    if (this.readyState == 4 && this.status == 200) {
//     	      document.getElementById("demo").innerHTML = virtual_id;
    	    }
    	  };
//     	  alert("inside  ");
    	  xhttp.open("GET", "ajax.jsp?get_device_id="+device_id, true);
//     	  alert("out side");
    	  xhttp.send();
    	}
      
      
      
//       RaiseChargeBack
       function RaiseChargeBack() {
//     	  alert("channel ");
    	  var mesg =   document.getElementById("charge_back").value;
//     	  alert("mesg    "+mesg);
//     	  alert("paasword   "+password);
    	  var xhttp = new XMLHttpRequest();
    	  xhttp.onreadystatechange = function() {
    	    if (this.readyState == 4 && this.status == 200) {
    	      document.getElementById("charge_back_status").innerHTML = this.responseText;
    	    }
    	  };
//     	  alert("inside  ");
    	  xhttp.open("GET", "ajax.jsp?charge_back="+mesg+"&raise_ticket=yes", true);
//     	  alert("out side");
    	  xhttp.send();
    	}
      
      //raise ticket
      function raiseTicket(channel,device_id,reference_num) {
//     	  alert("channel   "+channel+"   device id  "+device_id+"   reference_num   "+reference_num);
//     	  var password =   document.getElementById("device_password").value;
//     	  alert("paasword   "+password);
    	  var xhttp = new XMLHttpRequest();
    	  xhttp.onreadystatechange = function() {
    	    if (this.readyState == 4 && this.status == 200) {
    	      document.getElementById("device_login_status").innerHTML = this.responseText;
    	    }
    	  };
//     	  alert("inside  ");
    	  xhttp.open("GET", "ajax.jsp?device_id="+device_id+"&channel_name="+channel+"&reference_num="+reference_num, true);
//     	  alert("out side");
    	  xhttp.send();
    	}
      

function validate_password() {
var password = document.getElementById("password").value;
var password1 = document.getElementById("password1").value;

  if(password != "" && password == password1) {
    if(password1.length < 6) {
    	$("#sixcaracters").show();
    	  $("#atleastonenumber").hide();
    	  $("#lowercase").hide();
    	  $("#uppercase").hide();
    	  $("#notmatched").hide();
    	  $("#emptypassword").hide();
//       alert("Error: Password must contain at least six characters!");
//    	password.focus();
      return false;
    }
    re = /[0-9]/;
    if(!re.test(password)) {
    	
    	$("#atleastonenumber").show();
    	  $("#sixcaracters").hide();
    	  $("#lowercase").hide();
    	  $("#uppercase").hide();
    	  $("#notmatched").hide();
    	  $("#emptypassword").hide();
//       alert("Error: password must contain at least one number (0-9)!");
//   password.focus();
      return false;
    }
    re = /[a-z]/;
    if(!re.test(password)) {
    	$("#lowercase").show();
    	  $("#sixcaracters").hide();
    	  $("#atleastonenumber").hide();
    	  $("#uppercase").hide();
    	  $("#notmatched").hide();
    	  $("#emptypassword").hide();
//       alert("Error: password must contain at least one lowercase letter (a-z)!");
//      password.focus();
      return false;
    }
    re = /[A-Z]/;
    if(!re.test(password)) {
    	$("#uppercase").show();
    	  $("#sixcaracters").hide();
    	  $("#atleastonenumber").hide();
    	  $("#lowercase").hide();
    	  $("#notmatched").hide();
    	  $("#emptypassword").hide();
//       alert("Error: password must contain at least one uppercase letter (A-Z)!");
//    password.focus();
      return false;
    }
    else {
    	
    	$("#loadingDiv").show();
    	return true;
    	
    }
  } 
  else if(password === "" || password1 === "") {
	
	  $("#emptypassword").show();
	  $("#notmatched").hide();
	  $("#sixcaracters").hide();
	  $("#atleastonenumber").hide();
	  $("#lowercase").hide();
	  $("#uppercase").hide();
	  return false;
  }
  else {
	  $("#emptypassword").hide();
		$("#notmatched").show();
		  $("#sixcaracters").hide();
		  $("#atleastonenumber").hide();
		  $("#lowercase").hide();
		  $("#uppercase").hide();
//     alert("Error: Please check that you've entered and confirmed your password!");
//     password.focus();
    return false;
  }
}


$(document).ready(function(){
//   alert("hiii  ");
  $("#sixcaracters").hide();
  $("#atleastonenumber").hide();
  $("#lowercase").hide();
  $("#uppercase").hide();
  $("#notmatched").hide();
  $("#emptypassword").hide();
});


//for resresh 

function refresh(from_date,to_date) {
// 	alert("refresh");
	$("#loadingDiv").show();
	window.location.href='statements.jsp?fdate='+from_date+'&tdate='+to_date;
}