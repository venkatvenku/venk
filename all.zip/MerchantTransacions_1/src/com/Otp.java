package com;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

/**
 * Servlet implementation class Otp
 */
public class Otp extends HttpServlet {
	final static Logger logger = Logger.getLogger(Otp.class);

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("login.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String accountNumber = (String)session.getAttribute("account_number");
		logger.info("account number   "+accountNumber);
//		String accountNumber = request.getParameter("account_number");
		String otp = request.getParameter("otp");

		JSONObject obj = new JSONObject();
		obj.put("accountNumber", accountNumber);
		obj.put("otp", otp);
		
		String data = obj.toString();
//		System.out.println("jsonobject   "+obj);
		logger.info("data   "+data);
		   Properties prop = new Properties();
		    ServletContext context = getServletContext();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(context.getRealPath("/WEB-INF/certificate.properties")));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
		        host = prop.getProperty("uatint_host");
		       
		    } catch (IOException e) {
		    	logger.error(e);
		    }		
		    
		    String validateOTP_URL = prop.getProperty("validateOTP_URL");
		    logger.info("validateOTP_URL   "+validateOTP_URL);
		    UrlCalls url = new UrlCalls();
		    String api_resp =url.APICall(validateOTP_URL,data,rs,host);
		    logger.info("response   "+api_resp);
		    if(api_resp.contains("Success")){
			   	 response.sendRedirect("pass.jsp");
		    }else{
		    	 session.setAttribute("otp_status", "Failed");
			   	 response.sendRedirect("otp1.jsp");
		    }
		    
	}

}
