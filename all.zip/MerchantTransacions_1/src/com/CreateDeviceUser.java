package com;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

/**
 * Servlet implementation class CreateDeviceUser
 */
public class CreateDeviceUser extends HttpServlet {
	public String create_deviceID_login(String pass,String user_virt_id,String accountNumber) {
		
		System.out.println("accountNumber  "+accountNumber+"  password   "+pass+"  virtual id  "+user_virt_id);
		
		
		String password = "";
		try {
			 MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));

		        StringBuilder sb = new StringBuilder();
		        for (byte b : hashInBytes) {
		            sb.append(String.format("%02x", b));
		        }
		        password = sb.toString();
		        System.out.println("encry prion password   "+password);
		}catch(Exception e) {
			e.getMessage();
		}
		
		JSONObject obj = new JSONObject();
		obj.put("accountNumber",accountNumber );
		obj.put("password", password);
		obj.put("userName", user_virt_id);

		
		String data = obj.toString();
		System.out.println("jsonobject   "+obj);
		
		   Properties prop = new Properties();
		    ServletContext context = getServletContext();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(context.getRealPath("/WEB-INF/certificate.properties")));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
		        host = prop.getProperty("uatint_host");
		       
		    } catch (IOException e) {
		        e.printStackTrace();
		    }		
		    
		    System.out.println("data coming in password page is  "+data);
		    String register_URL = prop.getProperty("register_URL");
		    System.out.println("register_URL    :    "+register_URL);
		    UrlCalls url = new UrlCalls();
			
		    String api_resp =url.APICall(register_URL,data,rs,host);
		    System.out.println("response in createdevice in java    "+api_resp);
		    if(api_resp.contains("custId")){
			   	 	    return "success";			   	 
		    }else{
			   	 return "failed";
		    }
		    	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	HttpSession session = request.getSession();
	String pass= request.getParameter("password");
	String user_virt_id= (String)session.getAttribute("add_virtual_id");
	String accountNumber= (String)session.getAttribute("login_accunt_number");
	
	System.out.println("accountNumber  "+accountNumber+"  password   "+pass+"  virtual id  "+user_virt_id);
	
	
	String password = "";
	try {
		 MessageDigest md = MessageDigest.getInstance("MD5");
	        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));

	        StringBuilder sb = new StringBuilder();
	        for (byte b : hashInBytes) {
	            sb.append(String.format("%02x", b));
	        }
	        password = sb.toString();
	        System.out.println("encry prion password   "+password);
	}catch(Exception e) {
		e.getMessage();
	}
	
	JSONObject obj = new JSONObject();
	obj.put("accountNumber",accountNumber );
	obj.put("password", password);
	obj.put("userName", user_virt_id);

	
	String data = obj.toString();
	System.out.println("jsonobject   "+obj);
	
	   Properties prop = new Properties();
	    ServletContext context = getServletContext();
	    Resources rs = null;
	    String host = "";
	    try {
	        prop.load(new FileReader(context.getRealPath("/WEB-INF/certificate.properties")));
	        AssignProperties asp = new AssignProperties();
	        rs = asp.setResources(prop);
	        host = prop.getProperty("uatint_host");
	       
	    } catch (IOException e) {
	        e.printStackTrace();
	    }		
	    
	    System.out.println("data coming in password page is  "+data);
	    String register_URL = prop.getProperty("register_URL");
	    System.out.println("register_URL    :    "+register_URL);
	    UrlCalls url = new UrlCalls();
		
	    String api_resp =url.APICall(register_URL,data,rs,host);
	    System.out.println("response in createdevice in java    "+api_resp);
	    if(api_resp.contains("custId")){
//	    	request.setAttribute("status", "success");
//		   	 request.getRequestDispatcher("login.jsp").forward(request, response);
		   	 	    System.out.println("inside if condition    in create device user");

		   	 response.sendRedirect("statements.jsp?success");
		   	 
	    }else{

		   	 		   	 	    System.out.println("inside  else condition    in create device user");

		   	 response.sendRedirect("statements.jsp?failed");
	    }
	    	}

}
