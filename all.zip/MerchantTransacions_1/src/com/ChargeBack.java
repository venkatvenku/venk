package com;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

public class ChargeBack{
	
	
	public String CreateChargeBack(String path,String device_id,String channel_name,String refernce_num,String accountNumber,String cgargeback_mesg) {
		
		System.out.println("refernce_num  "+refernce_num+"  cgargeback_mesg  "+cgargeback_mesg+" channel_name  "+channel_name+"  accountNumber  "+accountNumber+"  device_id   "+device_id);
				
		String password = "";
		try {
			 MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));

		        StringBuilder sb = new StringBuilder();
		        for (byte b : hashInBytes) {
		            sb.append(String.format("%02x", b));
		        }
		        password = sb.toString();
		        System.out.println("encry prion password   "+password);
		}catch(Exception e) {
			e.getMessage();
		}
		
		JSONObject obj = new JSONObject();
		obj.put("accountNumber",accountNumber );
		obj.put("referenceNumber", refernce_num);
		obj.put("chargeBack", cgargeback_mesg);
		obj.put("channel", channel_name);
		obj.put("deviceId", device_id);

		
		String data = obj.toString();
		System.out.println("jsonobject   "+obj);
		
		   Properties prop = new Properties();
		    Resources rs = null;
		    String host = "";
		    try {
		    	System.out.println("[path   "+path);
		        prop.load(new FileReader(path));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
		        host = prop.getProperty("uatint_host");
		       
		    } catch (IOException e) {
		        e.printStackTrace();
		    }		
		    
		    System.out.println("data coming in password page is  "+data);
		    String charge_back_URL = prop.getProperty("charge_back");
		    System.out.println("charge_back    :    "+charge_back_URL);
		    UrlCalls url = new UrlCalls();
			
		    String api_resp =url.APICall(charge_back_URL,data,rs,host);
		    System.out.println("response in charge back in java    "+api_resp);
		    if(api_resp.contains("Success")){
			   	 	    return "success";			   	 
		    }else{
			   	 return "failed";
		    }
		  }
}
