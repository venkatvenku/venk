package com;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

/**
 * Servlet implementation class Password
 */
@WebServlet("/Password")
public class Password extends HttpServlet {
	final static Logger logger = Logger.getLogger(Password.class);
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("login.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String pass = request.getParameter("password");
		logger.info("password  "+pass);
		String accountNumber = (String)session.getAttribute("account_number");
		logger.info("accountNumber     "+accountNumber);
		String password = "";
		try {
			 MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] hashInBytes = md.digest(pass.getBytes(StandardCharsets.UTF_8));

		        StringBuilder sb = new StringBuilder();
		        for (byte b : hashInBytes) {
		            sb.append(String.format("%02x", b));
		        }
		        password = sb.toString();
		        logger.info("encryprion password   "+password);
		}catch(Exception e) {
			logger.error(e);
//			e.getMessage();
		}
		
		JSONObject obj = new JSONObject();
		obj.put("accountNumber", accountNumber);
		obj.put("password", password);
		obj.put("userName", accountNumber);
		
		String data = obj.toString();
		logger.info("data  "+data);
//		System.out.println("jsonobject   "+obj);
		
		   Properties prop = new Properties();
		    ServletContext context = getServletContext();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(context.getRealPath("/WEB-INF/certificate.properties")));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
		        host = prop.getProperty("uatint_host");
//		        host = prop.getProperty("test_host");
		        
//		        System.out.println("host in password   "+host);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }		
		    
		    String register_URL = prop.getProperty("register_URL");
		    logger.info("register_URL    :    "+register_URL);
		    UrlCalls url = new UrlCalls();
			
		    String api_resp =url.APICall(register_URL,data,rs,host);
		    logger.info("response   "+api_resp);
		    if(api_resp.contains("custId")){
		    	 session.setAttribute("signup_status", "success");
			   	 response.sendRedirect("log.jsp");
			   	 
		    }else{
		    	 session.setAttribute("status", "failed");
			   	 response.sendRedirect("sign.jsp");
		    }
		    	}

}
