package com;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;


public class Login extends HttpServlet {
	
	static Properties prop = new Properties();
	public static String CheckUser(String account_number,String path) {
		
		JSONObject obj = new JSONObject();		
		obj.put("accountNumber", account_number);

		
	    Resources rs = null;
	    String host = "";
	    try {
	        prop.load(new FileReader(path));
	        AssignProperties asp = new AssignProperties();
	        rs = asp.setResources(prop);
	        host = prop.getProperty("uatint_host");
	       
	    } catch (IOException e) {
	        e.printStackTrace();
	    }		
	    String data = obj.toString();
	    String device_account_number = prop.getProperty("device_account_number");
	    logger.info("device_account_number  "+device_account_number);
	    UrlCalls url = new UrlCalls();
	    String api_resp =url.APICall(device_account_number,data,rs,host);
	    String device_accountnumber = "";
	    if(api_resp.contains("Success")) {
	    	 JSONObject jobj = new JSONObject(api_resp);
	    	 device_accountnumber   = (String)jobj.get("AccountNumber");
	    }else {
	    	device_accountnumber = "NA";
	    }   
		return device_accountnumber;
	}
	
	final static Logger logger = Logger.getLogger(Login.class);
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("login.jsp");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String accountNumber = request.getParameter("account_number");
		String user_name = request.getParameter("user_name");
		String pass = request.getParameter("password");
		String device_login = request.getParameter("device_login");//only use for device login time
		HttpSession session = request.getSession();
		ServletContext context = getServletContext();
		String path = context.getRealPath("/WEB-INF/certificate.properties");
		String device_accountNumber = CheckUser(accountNumber,path);
		logger.info("device_accountNumber  "+device_accountNumber);

		if(device_accountNumber.equalsIgnoreCase("NA") || device_accountNumber == null) {
			logger.info("account number  "+accountNumber);
			logger.info("password  "+pass);
			String password = "";
			try {
				 MessageDigest md = MessageDigest.getInstance("MD5");
			        byte[] hashInBytes = md.digest(pass.getBytes(StandardCharsets.UTF_8));

			        StringBuilder sb = new StringBuilder();
			        for (byte b : hashInBytes) {
			            sb.append(String.format("%02x", b));
			        }
			        password = sb.toString();
			        logger.info("encryprion password  "+password);
			}catch(Exception e) {
				e.getMessage();
			}
			
			
			
			
			JSONObject obj = new JSONObject();
			obj.put("accountNumber", accountNumber);
			obj.put("password", password);
			obj.put("userName", user_name);
			
			String data = obj.toString();
			logger.info("jsonobject  "+obj);
			logger.info("String data   "+data);
			   
//			    ServletContext context = getServletContext();
			    Resources rs = null;
			    String host = "";
			    try {
			        prop.load(new FileReader(path));
			        AssignProperties asp = new AssignProperties();
			        rs = asp.setResources(prop);
			        host = prop.getProperty("uatint_host");
			       
			    } catch (IOException e) {
			        e.printStackTrace();
			    }		
			    
			    String Login_URL = prop.getProperty("login_URL");
			    logger.info("Login_URL   "+Login_URL);
			    UrlCalls url = new UrlCalls();
			    String api_resp =url.APICall(Login_URL,data,rs,host);
			    logger.info("api_resp   "+api_resp);
			    if(api_resp.contains("Success")){
			    	logger.info("inside if condition ");	
//			    	session.setAttribute("final_data", api_resp);
			    	
			    	JSONObject jsonObject = new JSONObject(api_resp);
			        session.setAttribute("account_number", (String)jsonObject.get("AccountNumber"));
			        session.setAttribute("MobileNumber", (String)jsonObject.get("MobileNumber"));
			        session.setAttribute("MerchantId", (String)jsonObject.get("MerchantId"));		
			        session.setAttribute("cust_id", (String)jsonObject.get("CustId"));
			        if(device_login != null && device_login != "") {
			    	 session.setAttribute("device_login_id", (String)jsonObject.get("AccountNumber"));	
			        }
			    	 session.setAttribute("login_accunt_number", accountNumber);	
			    	 session.setAttribute("login_password", pass);
			    	 response.sendRedirect("statements.jsp");
			    }
			    
			    else if(api_resp.contains("Failed")) {
			    	logger.info("inside else if condition ");	
			    	session.setAttribute("login_status", "failed");
			    	request.getRequestDispatcher("log.jsp").forward(request, response);
			    }  
			    else {
			    	logger.info("inside else condition ");	
			    	session.setAttribute("login_status", "login denied");
			    	request.getRequestDispatcher("log.jsp").forward(request, response);
			    }
		}
		else {
			session.setAttribute("user_login_status", "Failed");
			response.sendRedirect("log.jsp");
		}
		
		    
	}

}
