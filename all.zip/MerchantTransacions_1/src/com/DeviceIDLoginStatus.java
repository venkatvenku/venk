package com;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

public class DeviceIDLoginStatus {
	final static Logger logger = Logger.getLogger(DeviceIDLoginStatus.class);

	public String getLoginStatus(String deviceId,String path) {
		

		logger.info("deviceId  "+deviceId);		
		
		JSONObject obj = new JSONObject();
		obj.put("device_id", deviceId);
			
		String data = obj.toString();
		logger.info("data  "+data);
		
		   Properties prop = new Properties();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(path));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
//		        host = prop.getProperty("uatint_host");
		        host ="10.251.111.22";
		        
//		        System.out.println("host in password   "+host);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }		
		    
		    String deviceid_loginstatus = prop.getProperty("deviceid_loginstatus");
		    logger.info("deviceid_loginstatus    :    "+deviceid_loginstatus);
		    UrlCalls url = new UrlCalls();
			
		    String api_resp =url.APICall(deviceid_loginstatus,data,rs,host);
		    logger.info("response   "+api_resp);
		    String status = "";
		    if(api_resp.contains("false")){
		    	status = "false";
			   	 
		    }else if(api_resp.contains("true")){
		    	
		    	status = "true";
		    }else {
		    	status="NO Records";
		    }
			return status;
	}
	
	
	public String updateDeviceLoginStatus(String path,String account_number,String status) {
			
		 logger.info("path  "+path+"  account_number  "+account_number+"  status  "+status);	
		String password = "";
		try {
			 MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));

		        StringBuilder sb = new StringBuilder();
		        for (byte b : hashInBytes) {
		            sb.append(String.format("%02x", b));
		        }
		        password = sb.toString();
		        System.out.println("encry prion password   "+password);
		}catch(Exception e) {
			e.getMessage();
		}
		
		JSONObject obj = new JSONObject();
		obj.put("accountNumber",account_number );
		obj.put("status", status);
		
		String data = obj.toString();
		logger.info("jsonobject   "+obj);
		
		   Properties prop = new Properties();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(path));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
		        host = prop.getProperty("uatint_host");
		       
		    } catch (IOException e) {
		        e.printStackTrace();
		    }		
		    
		    System.out.println("data coming in password page is  "+data);
		    String update_deviceid_loginstatus = prop.getProperty("update_deviceid_loginstatus");
		    System.out.println("update_deviceid_loginstatus    :    "+update_deviceid_loginstatus);
		    UrlCalls url = new UrlCalls();
			
		    String api_resp =url.APICall(update_deviceid_loginstatus,data,rs,host);
		    logger.info("response   "+api_resp);
		    if(api_resp.contains("Success")){
			   	 	    return "success";			   	 
		    }else{
			   	 return "failed";
		    }
	}
}
