package com.client;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.Response.Status;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

 public class simpleURL
{
	 //API URL
	 static String api_URL = "";
	 //properties file names
	 static String keys_data = "resources.properties";//keys Data
	 static String json_data = "json.properties";//Json Data
	
	 static
		{
		 	Properties prop = new Properties();
			String path = System.getProperty("user.dir");
			FileInputStream input;
			try {
				input = new FileInputStream(path + "\\"+keys_data);
				System.out.println(path);
				prop.load(input);
			} catch (IOException e) {
				e.printStackTrace();
			}
			api_URL = prop.getProperty("api_URL");
			System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
			System.setProperty("https.protocols", "TLSv1.2");
			
			//trust store
			System.setProperty("javax.net.ssl.trustStore", prop.getProperty("trustStoreLocation"));
			System.setProperty("javax.net.ssl.trustStorePassword", prop.getProperty("trustStorePass"));
			
			//key store
			System.setProperty("javax.net.ssl.keyStore",prop.getProperty("keyStoreLocation"));
	        System.setProperty("javax.net.ssl.keyStorePassword", prop.getProperty("keyStorePass"));
			
	        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
        };
 
        // FOR Disabling the Truststore validation the all-trusting trust manager
//        SSLContext sc = null;
//		try {
//			sc = SSLContext.getInstance("SSL");
//		} catch (NoSuchAlgorithmException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        try {
//			sc.init(null, trustAllCerts, new java.security.SecureRandom());
//		} catch (KeyManagementException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        
			javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
					new javax.net.ssl.HostnameVerifier() {
//						int i = api_URL.indexOf("/");
//						int k = api_URL.lastIndexOf(":");
//						String ip_address = api_URL.substring(i+2, k);
						public boolean verify(String hostname,
								javax.net.ssl.SSLSession sslSession) {
							if (hostname.equals("10.199.14.40")) {
								return true;
							}
							return false;
						}
					});
		}
	 //main method
   public static void main (String [] argv)
   {
     setupHandler();
     connectToURL(api_URL);
     
 	try {
 		Client client = Client.create();		
		String json_data = new String(Files.readAllBytes(Paths.get("json.properties")));
    
//		 String name = "naren_mtwop";
//		 String password = "federal@1234";
//		 String authString = name + ":" + password;
//		 String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
//		 .header("Authorization", "Basic " + authStringEnc).header("x-ibm-client-id", "efce53eb-43a0-4abe-bdba-0f82fe4efa26").header("x-ibm-client-secret", "F3kN0yJ5aJ2oO0mX1cQ3dW2mX7oQ4bF0dC7qR7xJ0mH3eN4hD1").
// 		client.setConnectTimeout(15*1000);
// 		client.setReadTimeout(15*1000);
		WebResource webResource = client.resource(api_URL);
 		
 		ClientResponse response = webResource.accept("application/json").type("application/json").post(ClientResponse.class,json_data);
 		String output = response.getEntity(String.class);
 	int status = response.getStatus();
		System.out.println("status code    :  "+status);

 		System.out.println("Request  :  "+json_data);
 		System.out.println("Response :  "+output);
 		
 	  }
 	catch (ClientHandlerException ch) {
		  System.out.println("inside clien handler exception   ");
//		st.printStackTrace();
	  } 
 	catch (SocketTimeoutException st) {
 		  System.out.println("inside socket time out exception   ");
// 		st.printStackTrace();
 	  } 
 	catch (Exception e) {
 		e.printStackTrace();
 	  }
     
   }
    private static void setupHandler()
   {
     java.util.Properties p = System.getProperties();
     String s = p.getProperty("java.protocol.handler.pkgs");
     if (s == null)
       s = "weblogic.net";
     else if (s.indexOf("weblogic.net") == -1)
       s += "|weblogic.net";
     p.put("java.protocol.handler.pkgs", s);
     System.setProperties(p);
   }
    
    private static void connectToURL(String theURLSpec)
   {
     try
     {
       URL theURL = new URL(theURLSpec);
       URLConnection urlConnection = theURL.openConnection();
       HttpURLConnection connection = null;
       if (!(urlConnection instanceof HttpURLConnection))
       {
         System.out.println("The URL is not using HTTP/HTTPS: " +
                              theURLSpec);
         return;
       }
       connection = (HttpURLConnection) urlConnection;
       connection.connect();
     }
     catch (IOException ioe)
     {
       System.out.println("Failure processing URL: " + theURLSpec);
       ioe.printStackTrace();
     }
   }
}